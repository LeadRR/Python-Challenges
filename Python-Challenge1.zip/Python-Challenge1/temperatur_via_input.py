# Degree Celsius to Fahrenheit and Kelvin converter

c = float(input("°Celsius?: "))

f = (c * 9 / 5) + 32
k = c + 273.15

print(f"{c}°C =", f"{f}°F =", f"{k}K")

# Celsius to Fahrenheit = (°C × 9/5) + 32
# Celsius to Kelvin = °C + 273.15
